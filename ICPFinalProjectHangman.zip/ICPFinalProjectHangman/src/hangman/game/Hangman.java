package hangman.game;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;


public class Hangman {
	
	//This method designs the game including the borders 
	//It writes the texts at centers
	public static void printMessage(String message, boolean top, boolean bottom) {
		
		//Draw the top border if top is true otherwise draw only side borders
		if (top) {
			System.out.println("+--------------------------------------+");
			System.out.print("|");
		}else {
			System.out.print("|");
		}
		
		//This centers text within the length if 38
		boolean front = true;
		for (int i = message.length(); i < 38; i++)
	    {
	        if (front)
	        {
	            message = " " + message;
	        }
	        else
	        {
	            message = message + " ";
	        }
	        front = !front;
	    }
		System.out.print(message.toString());
		
		//Draw the bottom border if bottom is true otherwise draw only side borders
		if (bottom)
	    {
	        System.out.println("|"); 
	        System.out.println("+--------------------------------------+"); 
	    }
	    else
	    {
	    	System.out.println("|"); 
	    }
		
	}
	
	//Systematically draw the hangman depending on quesscount(error guesess)
	public static void drawHangman(int guessCount) {
		if (guessCount >= 1)
			printMessage("|", false, false);
	    else
	    	printMessage("", false, false);
	 
	    if (guessCount >= 2)
	    	printMessage("|", false, false);
	    else
	    	printMessage("", false, false);
	 
	    if (guessCount >= 3)
	    	printMessage("O", false, false);
	    else
	    	printMessage("", false, false);
	 
	    if (guessCount == 4)
	    	printMessage("/  ", false, false);
	   
	    if (guessCount == 5)
	    	printMessage("/| ", false, false);
	 
	    if (guessCount >= 6)
	    	printMessage("/|\\", false, false);
	    else
	    	printMessage("", false, false);
	 
	    if (guessCount >= 7)
	    	printMessage("|", false, false);
	    else
	    	printMessage("", false, false);
	 
	    if (guessCount == 8)
	    	printMessage("/", false, false);
	 
	    if (guessCount >= 9)
	    	printMessage("/ \\", false, false);
	    else
	    	printMessage("", false, false);
	}

	//Prints the letters guessed so far
	public static void PrintLetters(String input, char from, char to)
	{
	    String s = "";
	    for (char i = from; i <= to; i++)
	    {
	        if (input.indexOf(i) == -1)
	        {
	            s += i;
	            s += " ";
	        }
	        else
	            s += "  ";
	    }
	    printMessage(s, false, false);
	}
	
	//Count and return number of wrong guesses
	public static int numberofTrials(String word, String guessed)
	{
	    int error = 0;
	    for (int i = 0; i < guessed.length(); i++)
	    {
	        if (word.indexOf(guessed.charAt(i)) ==-1)
	            error++;
	    }
	    return error;
	}
	
	//Prints letters guessed so far and returns true if all the leeters matched and false otherwise
	public static boolean PrintWordAndCheckWin(String word, String guessed)
	{
		boolean won = true;
		String s="";
	    for (int i = 0; i < word.length(); i++)
	    {
	        if (guessed.indexOf(word.charAt(i)) == -1)
	        {
	            won = false;
	            s += "_ ";
	        }
	        else
	        {
	            s += word.charAt(i);
	            s += " ";
	        }
	    }
	    printMessage(s, false, true);
	    return won;
	}
	
	//Removes the letters guessed and prints remaining letters
	public static void PrintAvailableLetters(String guessed)
	{
		printMessage("Available letters", true,true);
	    PrintLetters(guessed, 'A', 'M');
	    PrintLetters(guessed, 'N', 'Z');
	}
	
	//Returns a random word from a file
	public static String loadRandomWordsFromFile(){
		Random rand = new Random();
		ArrayList<String> strs = new ArrayList<>();
		
		String word;
		
		BufferedReader reader;
		try {
			reader = new BufferedReader(new FileReader("words.txt"));
			String line = reader.readLine();
			
			while (line !=null) {
				strs.add(line);
				line = reader.readLine();
			}
			
			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		int  randomValue = rand.nextInt(strs.size());
		word = strs.get(randomValue);
		return word;
	}
	
	//This method acts as a function that clears the console during runtime becuase Java does not have 
	//in-built funtion that clears the console
	private static void clearScreen() {
	    for (int i = 0; i < 20; i++) {
	        System.out.println();
	    }
	}
	public static void main(String[] args) {
		Database myDatabase = new Database();   //Intance of a database
		Scanner scan = new Scanner(System.in);
		boolean win = false;
		String guess = "";
		String randomWord = loadRandomWordsFromFile().toUpperCase();
		System.out.println(randomWord);
		int triesLeft = 0;
		
		System.out.print("Enter your playing name: ");
		String name = scan.nextLine();
		
		do {
		clearScreen();
		printMessage("HANGMAN GAME", true, true);
		drawHangman(triesLeft);
		PrintAvailableLetters(guess);
		printMessage("guessed word", true, true);
		
		win = PrintWordAndCheckWin(randomWord, guess);
		 
        char x;
        System.out.print("Guess by letters >");
        x = scan.next().toUpperCase().charAt(0);
 
        if (guess.indexOf(x) ==-1)
        	guess += x;
		triesLeft = numberofTrials(randomWord, guess);
		}while(triesLeft<10 & win !=true);
	 
		if(win) {
			printMessage("YOU WON", true, true);
			myDatabase.addPlayer(name, triesLeft);
		}else {
			printMessage("GAME OVER", true, true);
		}
		
		System.out.print("Want to check scores>");
		String scores = scan.next();
		
		if (scores.equalsIgnoreCase("yes")) {
			myDatabase.printScorers();
		}
		else {
			printMessage("THANK YOU FOR PLAYING", true, true);
		}
		
		
	}

}
