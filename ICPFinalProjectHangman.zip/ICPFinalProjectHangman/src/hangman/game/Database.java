package hangman.game;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Database {
    Connection con;
    PreparedStatement pst; //This is new thing right!
    ResultSet rs;
    static final String DB_URL = "jdbc:mysql://localhost:3306/hangman";
    static final String USER = "root";
    static final String PASSWORD = "Leila@1995";
    static final String MY_DRIVER = "com.mysql.jdbc.Driver";
    
    
	public Database() {
        try{
            Class.forName(MY_DRIVER);
            con=DriverManager.getConnection(DB_URL,USER,PASSWORD);
            
           }
        catch (Exception e) 
        {
            System.out.println(e);
        }
    }
	
	public void addPlayer(String name, int trials) {
		//This inserts a new player and the number of times he gueses wrong letters
		try {
			String sql = "INSERT INTO players (name, trials)" + "VALUES (?,?)";
			pst = con.prepareStatement(sql);
			pst.setString(1, name);
			pst.setInt(2, trials);
			pst.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void printScorers() {
		try {
			Statement myStat = con.createStatement();  //Create a statement
			rs = myStat.executeQuery("SELECT * FROM players order by trials"); //Query data from players table
			while(rs.next()) {
				System.out.println(rs.getString("name").toUpperCase() + " " + rs.getString("trials"));  //Process the result by printing out to console
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
